#!/bin/bash

while true; do
    xterm &
    sleep 1
done
